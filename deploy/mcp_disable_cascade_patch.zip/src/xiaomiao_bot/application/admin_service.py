"""Admin panel service."""

from __future__ import annotations

import re
import subprocess
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from nonebot import get_bots
from openai import AsyncOpenAI

from ..application.admin_auth_service import AdminAuthService
from ..application.minecraft_service import MinecraftService
from ..application.prompt_defaults import (
    DEFAULT_PROMPT_BASE,
    DEFAULT_PROMPT_LOGIC_AT_ME,
    DEFAULT_PROMPT_LOGIC_GROUP,
    DEFAULT_PROMPT_LOGIC_POKE,
    DEFAULT_PROMPT_LOGIC_PRIVATE,
    DEFAULT_PROMPT_SUMMARY_SYSTEM,
)
from ..application.scheduled_task_service import ScheduledTaskService
from ..application.secret_service import SecretService
from ..core.constants import (
    CFG_BLOCKED_GROUPS,
    CFG_BLOCKED_USERS,
    CFG_PROMPT_BASE,
    CFG_PROMPT_LOGIC_AT_ME,
    CFG_PROMPT_LOGIC_GROUP,
    CFG_PROMPT_LOGIC_POKE,
    CFG_PROMPT_LOGIC_PRIVATE,
    CFG_PROMPT_SUMMARY_SYSTEM,
)
from ..core.logging import get_logger
from ..infrastructure.database import database, dumps_json, loads_json
from ..infrastructure.runtime_config_store import RuntimeConfigStore
from ..infrastructure.session_store import session_store
from ..tools import ToolRegistry

logger = get_logger("后台服务")


class AdminService:
    """Admin APIs backing service."""

    MCP_PRESETS: dict[str, dict[str, Any]] = {
        "filesystem": {
            "server_name": "filesystem",
            "display_name": "文件系统",
            "transport": "stdio",
            "command": "npx",
            "args_json": ["-y", "@modelcontextprotocol/server-filesystem", "/app"],
            "env_json": {},
            "timeout_seconds": 20,
            "admin_only": True,
            "install_steps": [["npm", "install", "-g", "@modelcontextprotocol/server-filesystem"]],
        },
        "memory": {
            "server_name": "memory",
            "display_name": "长期记忆",
            "transport": "stdio",
            "command": "npx",
            "args_json": ["-y", "@modelcontextprotocol/server-memory"],
            "env_json": {},
            "timeout_seconds": 20,
            "admin_only": True,
            "install_steps": [["npm", "install", "-g", "@modelcontextprotocol/server-memory"]],
        },
        "thinking": {
            "server_name": "thinking",
            "display_name": "步骤思考",
            "transport": "stdio",
            "command": "npx",
            "args_json": ["-y", "@modelcontextprotocol/server-sequential-thinking"],
            "env_json": {},
            "timeout_seconds": 20,
            "admin_only": True,
            "install_steps": [["npm", "install", "-g", "@modelcontextprotocol/server-sequential-thinking"]],
        },
        "git": {
            "server_name": "git",
            "display_name": "Git 仓库",
            "transport": "stdio",
            "command": "uvx",
            "args_json": ["mcp-server-git", "--repository", "/app"],
            "env_json": {},
            "timeout_seconds": 20,
            "admin_only": True,
            "install_steps": [["uvx", "--from", "mcp-server-git", "mcp-server-git", "--help"]],
            "prepare_git_repo": "/app",
        },
    }

    def __init__(
        self,
        runtime_config_store: RuntimeConfigStore,
        secret_service: SecretService,
        admin_auth_service: AdminAuthService,
        minecraft_service: MinecraftService,
        scheduled_task_service: ScheduledTaskService,
        tools: ToolRegistry,
    ) -> None:
        self.runtime_config_store = runtime_config_store
        self.secret_service = secret_service
        self.admin_auth_service = admin_auth_service
        self.minecraft_service = minecraft_service
        self.scheduled_task_service = scheduled_task_service
        self.tools = tools

    def get_overview(self) -> dict[str, Any]:
        since = datetime.now() - timedelta(hours=24)
        group_msg = session_store.count_recent_messages(session_type="group", since=since)
        private_msg = session_store.count_recent_messages(session_type="private", since=since)
        group_summary = self._count(
            "SELECT COUNT(*) AS total FROM bot_group_summary WHERE created_at >= %s",
            (since,),
        )
        private_summary = self._count(
            "SELECT COUNT(*) AS total FROM bot_private_summary WHERE created_at >= %s",
            (since,),
        )
        tool_messages = session_store.count_recent_messages(session_type="group", since=since, role="tool")
        tool_messages += session_store.count_recent_messages(session_type="private", since=since, role="tool")
        failed_ai_calls = self._count(
            "SELECT COUNT(*) AS total FROM bot_ai_call_log WHERE is_success=0 AND created_at >= %s",
            (since,),
        )
        recent_failures = database.fetch_all(
            """
            SELECT id, session_type, session_id, stage, model_name, failure_reason, latency_ms, created_at
            FROM bot_ai_call_log
            WHERE is_success=0
            ORDER BY id DESC
            LIMIT 10
            """,
            (),
        )
        recent_changes = database.fetch_all(
            """
            SELECT id, config_domain, scope_ref, change_type, changed_by, created_at
            FROM bot_config_change_log
            ORDER BY id DESC
            LIMIT 10
            """,
            (),
        )
        return {
            "stats": {
                "messages_24h": int(group_msg + private_msg),
                "summaries_24h": int(group_summary + private_summary),
                "tool_messages_24h": int(tool_messages),
                "ai_failures_24h": int(failed_ai_calls),
            },
            "runtime_config": self.runtime_config_store.get_runtime_snapshot(),
            "recent_failures": recent_failures,
            "recent_config_changes": recent_changes,
        }

    def get_runtime_config(self) -> dict[str, Any]:
        return {
            **self.runtime_config_store.get_runtime_snapshot(),
            **self.minecraft_service.get_runtime_config(),
        }

    def update_runtime_config(self, payload: dict[str, Any], *, changed_by: str) -> dict[str, Any]:
        before = self.get_runtime_config()
        runtime_payload = dict(payload)
        minecraft_notify_groups = runtime_payload.pop("minecraft_notify_groups", None)
        self.runtime_config_store.update_runtime_settings(runtime_payload)
        if minecraft_notify_groups is not None:
            self.minecraft_service.update_runtime_config(
                minecraft_notify_groups=[int(item) for item in minecraft_notify_groups],
            )
        after = self.get_runtime_config()
        self._log_config_change(
            config_domain="ai_runtime",
            scope_ref="global:default",
            change_type="update",
            before_json=before,
            after_json=after,
            changed_by=changed_by,
        )
        return after

    async def test_ai_connection(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        payload = payload or {}
        runtime = self.runtime_config_store.get_runtime_snapshot()
        base_url = str(payload.get("ai_base_url") or runtime.get("ai_base_url") or "").strip()
        model = str(payload.get("text_model") or runtime.get("text_model") or "").strip()
        enable_tools = bool(payload.get("enable_tools", runtime.get("enable_tools", False)))
        api_key = self.secret_service.get_secret("AI_API_KEY", "")
        if not base_url:
            return {"ok": False, "message": "AI Base URL 未配置"}
        if not model:
            return {"ok": False, "message": "文本模型未配置", "base_url": base_url}
        if not api_key:
            return {"ok": False, "message": "AI_API_KEY 未配置", "base_url": base_url, "model": model}

        started_at = time.perf_counter()
        result: dict[str, Any] = {
            "ok": False,
            "base_url": base_url,
            "model": model,
            "tools_enabled": enable_tools,
            "tools_supported": None,
        }
        client = AsyncOpenAI(api_key=api_key, base_url=base_url, timeout=20)
        messages = [
            {"role": "system", "content": "你是连接测试助手，只回复 OK。"},
            {"role": "user", "content": "连接测试，请只回复 OK。"},
        ]
        try:
            response = await client.chat.completions.create(
                model=model,
                messages=messages,
                max_tokens=32,
            )
            content = str(response.choices[0].message.content or "").strip()
            result.update(
                {
                    "ok": bool(content),
                    "message": "模型连接正常" if content else "模型返回为空",
                    "sample": content[:80],
                }
            )
        except Exception as exc:  # noqa: BLE001
            result.update(
                {
                    "ok": False,
                    "message": "模型连接失败",
                    "error": self._public_error(exc),
                    "latency_ms": int((time.perf_counter() - started_at) * 1000),
                }
            )
            return result

        if enable_tools:
            tool_started_at = time.perf_counter()
            try:
                await client.chat.completions.create(
                    model=model,
                    messages=messages,
                    max_tokens=32,
                    tools=[
                        {
                            "type": "function",
                            "function": {
                                "name": "health_echo",
                                "description": "后台健康检查用的空工具。",
                                "parameters": {
                                    "type": "object",
                                    "properties": {},
                                    "additionalProperties": False,
                                },
                            },
                        }
                    ],
                    tool_choice="auto",
                )
                result["tools_supported"] = True
                result["tools_message"] = "工具参数可用"
            except Exception as exc:  # noqa: BLE001
                result["tools_supported"] = False
                result["tools_message"] = self._public_error(exc)
            result["tools_latency_ms"] = int((time.perf_counter() - tool_started_at) * 1000)

        result["latency_ms"] = int((time.perf_counter() - started_at) * 1000)
        return result

    async def get_health(self, *, run_ai_check: bool = False) -> dict[str, Any]:
        runtime = self.runtime_config_store.get_runtime_snapshot()
        now = datetime.now()
        checks: list[dict[str, Any]] = []

        db_started_at = time.perf_counter()
        db_ok = False
        db_message = "数据库异常"
        try:
            row = database.fetch_one("SELECT 1 AS ok", ())
            db_ok = int((row or {}).get("ok") or 0) == 1
            db_message = "MySQL 正常" if db_ok else "MySQL 返回异常"
        except Exception as exc:  # noqa: BLE001
            db_message = self._public_error(exc)
        checks.append(
            {
                "key": "mysql",
                "label": "MySQL",
                "ok": db_ok,
                "status": "normal" if db_ok else "error",
                "message": db_message,
                "latency_ms": int((time.perf_counter() - db_started_at) * 1000),
            }
        )

        bots = get_bots()
        onebot_ok = bool(bots)
        checks.append(
            {
                "key": "onebot",
                "label": "OneBot / NapCat",
                "ok": onebot_ok,
                "status": "normal" if onebot_ok else "warning",
                "message": f"已连接 {len(bots)} 个 Bot" if onebot_ok else "当前没有 OneBot 连接",
            }
        )

        tools_enabled = bool(runtime.get("enable_tools"))
        checks.append(
            {
                "key": "tools",
                "label": "工具调用",
                "ok": tools_enabled,
                "status": "normal" if tools_enabled else "warning",
                "message": "工具总开关已开启" if tools_enabled else "工具总开关已关闭",
            }
        )

        ai_result: dict[str, Any] | None = None
        if run_ai_check:
            ai_result = await self.test_ai_connection({})
            checks.append(
                {
                    "key": "ai",
                    "label": "AI 模型",
                    "ok": bool(ai_result.get("ok")),
                    "status": "normal" if ai_result.get("ok") else "error",
                    "message": ai_result.get("message") or "-",
                    "latency_ms": ai_result.get("latency_ms"),
                    "detail": {
                        key: value
                        for key, value in ai_result.items()
                        if key not in {"base_url", "model"}
                    },
                }
            )
        else:
            checks.append(
                {
                    "key": "ai",
                    "label": "AI 模型",
                    "ok": None,
                    "status": "unknown",
                    "message": "点击一键检测后实时测试",
                }
            )

        failed_10m = self._count(
            """
            SELECT COUNT(*) AS total
            FROM bot_ai_call_log
            WHERE is_success=0
              AND created_at >= DATE_SUB(NOW(), INTERVAL 10 MINUTE)
            """,
            (),
        )
        checks.append(
            {
                "key": "ai_failures",
                "label": "近期 AI 失败",
                "ok": failed_10m == 0,
                "status": "normal" if failed_10m == 0 else ("warning" if failed_10m < 5 else "error"),
                "message": f"最近 10 分钟失败 {failed_10m} 次",
            }
        )
        last_success = database.fetch_one(
            """
            SELECT stage, model_name, latency_ms, created_at
            FROM bot_ai_call_log
            WHERE is_success=1
            ORDER BY created_at DESC
            LIMIT 1
            """,
            (),
        )
        return {
            "checked_at": now,
            "overall_status": "normal"
            if all(item.get("status") != "error" for item in checks)
            else "error",
            "checks": checks,
            "runtime": {
                "ai_base_url": runtime.get("ai_base_url"),
                "text_model": runtime.get("text_model"),
                "vision_model": runtime.get("vision_model"),
                "enable_tools": bool(runtime.get("enable_tools")),
                "enable_summary_memory": bool(runtime.get("enable_summary_memory")),
            },
            "metrics": {
                "ai_failures_10m": failed_10m,
                "bot_connections": len(bots),
                "last_success_ai_call": last_success,
            },
            "ai_test": ai_result,
        }

    def get_prompts(self) -> dict[str, Any]:
        return {
            "prompt_base": str(self.runtime_config_store.get(CFG_PROMPT_BASE, DEFAULT_PROMPT_BASE)),
            "prompt_logic_private": str(
                self.runtime_config_store.get(CFG_PROMPT_LOGIC_PRIVATE, DEFAULT_PROMPT_LOGIC_PRIVATE)
            ),
            "prompt_logic_at_me": str(
                self.runtime_config_store.get(CFG_PROMPT_LOGIC_AT_ME, DEFAULT_PROMPT_LOGIC_AT_ME)
            ),
            "prompt_logic_poke": str(
                self.runtime_config_store.get(CFG_PROMPT_LOGIC_POKE, DEFAULT_PROMPT_LOGIC_POKE)
            ),
            "prompt_logic_group": str(
                self.runtime_config_store.get(CFG_PROMPT_LOGIC_GROUP, DEFAULT_PROMPT_LOGIC_GROUP)
            ),
            "prompt_summary_system": str(
                self.runtime_config_store.get(CFG_PROMPT_SUMMARY_SYSTEM, DEFAULT_PROMPT_SUMMARY_SYSTEM)
            ),
        }

    def update_prompts(self, payload: dict[str, Any], *, changed_by: str) -> dict[str, Any]:
        before = self.get_prompts()
        self.runtime_config_store.update(payload)
        after = self.get_prompts()
        self._log_config_change(
            config_domain="prompt",
            scope_ref="global",
            change_type="update",
            before_json=before,
            after_json=after,
            changed_by=changed_by,
        )
        return after

    def get_blocklist(self) -> dict[str, Any]:
        return {
            "blocked_groups": self.runtime_config_store.get_list(CFG_BLOCKED_GROUPS, []),
            "blocked_users": self.runtime_config_store.get_list(CFG_BLOCKED_USERS, []),
        }

    def update_blocklist(
        self,
        *,
        blocked_groups: list[int] | None,
        blocked_users: list[int] | None,
        changed_by: str,
    ) -> dict[str, Any]:
        before = self.get_blocklist()
        payload: dict[str, Any] = {}
        if blocked_groups is not None:
            payload[CFG_BLOCKED_GROUPS] = blocked_groups
        if blocked_users is not None:
            payload[CFG_BLOCKED_USERS] = blocked_users
        self.runtime_config_store.update(payload)
        after = self.get_blocklist()
        self._log_config_change(
            config_domain="blocklist",
            scope_ref="global",
            change_type="update",
            before_json=before,
            after_json=after,
            changed_by=changed_by,
        )
        return after

    def list_secrets(self) -> list[dict[str, Any]]:
        return self.secret_service.list_secrets()

    def update_secret(
        self,
        *,
        secret_key: str,
        secret_value: str,
        value_hint: str | None,
        changed_by: str,
    ) -> dict[str, Any]:
        before = self._find_secret_public(secret_key)
        after = self.secret_service.update_secret(
            secret_key,
            secret_value,
            updated_by=changed_by,
            value_hint=value_hint,
        )
        self._log_config_change(
            config_domain="secret",
            scope_ref=secret_key,
            change_type="update" if before else "create",
            before_json=before,
            after_json=after,
            changed_by=changed_by,
        )
        return after

    def list_tools(self) -> list[dict[str, Any]]:
        rows = database.fetch_all(
            """
            SELECT
                id, tool_name, display_name, description, parameters_json, tool_type,
                method, url, headers_json, body_template,
                python_code, python_entry, python_allow_network, python_timeout_seconds,
                timeout_seconds, is_enabled,
                created_at, updated_at
            FROM bot_tool_config
            ORDER BY tool_type ASC, tool_name ASC
            """,
            (),
        )
        for row in rows:
            row["parameters_json"] = loads_json(
                str(row.get("parameters_json")) if row.get("parameters_json") is not None else None,
                {},
            )
            row["headers_json"] = loads_json(
                str(row.get("headers_json")) if row.get("headers_json") is not None else None,
                {},
            )
        return rows

    def list_scheduled_tasks(
        self,
        *,
        page: int,
        page_size: int,
        keyword: str = "",
        status: str = "",
        target_type: str = "",
    ) -> dict[str, Any]:
        return self.scheduled_task_service.list_tasks(
            page=page,
            page_size=page_size,
            keyword=keyword,
            status=status,
            target_type=target_type,
        )

    def create_scheduled_task(self, payload: dict[str, Any], *, changed_by: str) -> dict[str, Any]:
        task = self.scheduled_task_service.create_task(payload, changed_by=changed_by)
        self._log_config_change(
            config_domain="scheduled_task",
            scope_ref=f"task:{task.get('id')}",
            change_type="create",
            before_json=None,
            after_json=task,
            changed_by=changed_by,
        )
        return task

    def update_scheduled_task(self, task_id: int, payload: dict[str, Any], *, changed_by: str) -> dict[str, Any]:
        before = self.scheduled_task_service.get_task(task_id)
        if not before:
            raise ValueError("定时任务不存在")
        task = self.scheduled_task_service.update_task(task_id, payload, changed_by=changed_by)
        self._log_config_change(
            config_domain="scheduled_task",
            scope_ref=f"task:{task_id}",
            change_type="update",
            before_json=before,
            after_json=task,
            changed_by=changed_by,
        )
        return task

    def delete_scheduled_task(self, task_id: int, *, changed_by: str) -> dict[str, Any]:
        before = self.scheduled_task_service.get_task(task_id)
        if not before:
            raise ValueError("定时任务不存在")
        result = self.scheduled_task_service.delete_task(task_id)
        self._log_config_change(
            config_domain="scheduled_task",
            scope_ref=f"task:{task_id}",
            change_type="delete",
            before_json=before,
            after_json=result,
            changed_by=changed_by,
        )
        return result

    async def run_scheduled_task_now(self, task_id: int, *, changed_by: str) -> dict[str, Any]:
        before = self.scheduled_task_service.get_task(task_id)
        if not before:
            raise ValueError("定时任务不存在")
        task = await self.scheduled_task_service.run_task_now(task_id)
        self._log_config_change(
            config_domain="scheduled_task",
            scope_ref=f"task:{task_id}",
            change_type="update",
            before_json=before,
            after_json=task,
            changed_by=changed_by,
        )
        return task

    def create_http_tool(self, payload: dict[str, Any], *, changed_by: str) -> dict[str, Any]:
        tool_name = str(payload.get("tool_name") or "").strip()
        if not tool_name:
            raise ValueError("tool_name 不能为空")
        if self._find_tool_config(tool_name):
            raise ValueError("工具名已存在")
        parameters_json = payload.get("parameters_json") or {
            "type": "object",
            "properties": {},
            "additionalProperties": True,
        }
        headers_json = payload.get("headers_json") or {}
        database.execute(
            """
            INSERT INTO bot_tool_config(
                tool_name, display_name, description, parameters_json, tool_type,
                method, url, headers_json, body_template, timeout_seconds, is_enabled
            ) VALUES(%s, %s, %s, %s, 'http', %s, %s, %s, %s, %s, %s)
            """,
            (
                tool_name,
                payload.get("display_name") or tool_name,
                payload.get("description") or "",
                dumps_json(parameters_json),
                str(payload.get("method") or "GET").upper(),
                str(payload.get("url") or "").strip(),
                dumps_json(headers_json),
                payload.get("body_template") or None,
                int(payload.get("timeout_seconds") or 15),
                1 if bool(payload.get("is_enabled", True)) else 0,
            ),
        )
        after = self._find_tool_config(tool_name)
        self._log_config_change(
            config_domain="tool",
            scope_ref=tool_name,
            change_type="create",
            before_json=None,
            after_json=after,
            changed_by=changed_by,
        )
        return after or {}

    def create_python_tool(self, payload: dict[str, Any], *, changed_by: str) -> dict[str, Any]:
        tool_name = str(payload.get("tool_name") or "").strip()
        if not tool_name:
            raise ValueError("tool_name 不能为空")
        if self._find_tool_config(tool_name):
            raise ValueError("工具名已存在")
        python_code = str(payload.get("python_code") or "").strip()
        if not python_code:
            raise ValueError("python_code 不能为空")
        if len(python_code) > 60000:
            raise ValueError("python_code 过长，最大 60000 字符")
        python_entry = str(payload.get("python_entry") or "main").strip() or "main"
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", python_entry):
            raise ValueError("python_entry 非法，仅允许字母数字下划线且不能数字开头")

        parameters_json = payload.get("parameters_json") or {
            "type": "object",
            "properties": {},
            "additionalProperties": True,
        }
        database.execute(
            """
            INSERT INTO bot_tool_config(
                tool_name, display_name, description, parameters_json, tool_type,
                python_code, python_entry, python_allow_network, python_timeout_seconds, is_enabled
            ) VALUES(%s, %s, %s, %s, 'python', %s, %s, %s, %s, %s)
            """,
            (
                tool_name,
                payload.get("display_name") or tool_name,
                payload.get("description") or "",
                dumps_json(parameters_json),
                python_code,
                python_entry,
                1 if bool(payload.get("python_allow_network", False)) else 0,
                min(60, max(1, int(payload.get("python_timeout_seconds") or 8))),
                1 if bool(payload.get("is_enabled", True)) else 0,
            ),
        )
        after = self._find_tool_config(tool_name)
        self._log_config_change(
            config_domain="tool",
            scope_ref=tool_name,
            change_type="create",
            before_json=None,
            after_json=after,
            changed_by=changed_by,
        )
        return after or {}

    def update_tool(self, tool_name: str, payload: dict[str, Any], *, changed_by: str) -> dict[str, Any]:
        before = self._find_tool_config(tool_name)
        if not before:
            raise ValueError("工具不存在")
        updates: list[str] = []
        params: list[Any] = []
        allowed_plain_fields = [
            "display_name",
            "description",
            "method",
            "url",
            "body_template",
            "timeout_seconds",
            "python_entry",
            "python_timeout_seconds",
        ]
        for field in allowed_plain_fields:
            if field not in payload:
                continue
            value = payload[field]
            if field == "method" and value is not None:
                value = str(value).upper()
            if field == "timeout_seconds" and value is not None:
                value = int(value)
            if field == "python_timeout_seconds" and value is not None:
                value = min(60, max(1, int(value)))
            if field == "python_entry" and value is not None:
                value = str(value).strip() or "main"
                if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", value):
                    raise ValueError("python_entry 非法，仅允许字母数字下划线且不能数字开头")
            updates.append(f"{field}=%s")
            params.append(value)
        if "is_enabled" in payload:
            updates.append("is_enabled=%s")
            params.append(1 if bool(payload["is_enabled"]) else 0)
        if "python_allow_network" in payload:
            updates.append("python_allow_network=%s")
            params.append(1 if bool(payload["python_allow_network"]) else 0)
        if "python_code" in payload:
            raw_code = str(payload["python_code"] or "")
            if raw_code and len(raw_code) > 60000:
                raise ValueError("python_code 过长，最大 60000 字符")
            updates.append("python_code=%s")
            params.append(raw_code or None)
        if "parameters_json" in payload:
            updates.append("parameters_json=%s")
            params.append(dumps_json(payload["parameters_json"]) if payload["parameters_json"] is not None else None)
        if "headers_json" in payload:
            updates.append("headers_json=%s")
            params.append(dumps_json(payload["headers_json"]) if payload["headers_json"] is not None else None)
        if not updates:
            return before
        params.append(tool_name)
        database.execute(
            f"UPDATE bot_tool_config SET {', '.join(updates)} WHERE tool_name=%s",
            tuple(params),
        )
        after = self._find_tool_config(tool_name)
        self._log_config_change(
            config_domain="tool",
            scope_ref=tool_name,
            change_type="update",
            before_json=before,
            after_json=after,
            changed_by=changed_by,
        )
        return after or before

    def delete_tool(self, tool_name: str, *, changed_by: str) -> dict[str, Any]:
        before = self._find_tool_config(tool_name)
        if not before:
            raise ValueError("工具不存在")
        if str(before.get("tool_type") or "") == "builtin":
            raise ValueError("内置工具不允许删除")
        database.execute("DELETE FROM bot_tool_config WHERE tool_name=%s", (tool_name,))
        self._log_config_change(
            config_domain="tool",
            scope_ref=tool_name,
            change_type="delete",
            before_json=before,
            after_json={"deleted": True, "tool_name": tool_name},
            changed_by=changed_by,
        )
        return {"deleted": True, "tool_name": tool_name}

    def list_mcp_servers(self) -> list[dict[str, Any]]:
        rows = database.fetch_all(
            """
            SELECT
                s.id, s.server_name, s.display_name, s.transport, s.command,
                s.args_json, s.env_json, s.url, s.headers_json, s.timeout_seconds,
                s.is_enabled, s.admin_only, s.last_status, s.last_error,
                s.created_at, s.updated_at,
                COALESCE(tc.tool_count, 0) AS tool_count
            FROM bot_mcp_server_config s
            LEFT JOIN (
                SELECT server_name, COUNT(*) AS tool_count
                FROM bot_mcp_tool_cache
                GROUP BY server_name
            ) tc ON s.server_name=tc.server_name
            ORDER BY s.server_name ASC
            """,
            (),
        )
        for row in rows:
            self._parse_mcp_json_fields(row)
        return rows

    def create_mcp_server(self, payload: dict[str, Any], *, changed_by: str) -> dict[str, Any]:
        server_name = self._validate_mcp_server_name(payload.get("server_name"))
        if self._find_mcp_server(server_name):
            raise ValueError("MCP 服务名已存在")
        transport = self._validate_mcp_transport(payload.get("transport"))
        timeout_seconds = min(120, max(1, int(payload.get("timeout_seconds") or 15)))
        database.execute(
            """
            INSERT INTO bot_mcp_server_config(
                server_name, display_name, transport, command, args_json, env_json,
                url, headers_json, timeout_seconds, is_enabled, admin_only
            ) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                server_name,
                payload.get("display_name") or server_name,
                transport,
                self._nullable_str(payload.get("command")),
                dumps_json(payload.get("args_json") or []),
                dumps_json(payload.get("env_json") or {}),
                self._nullable_str(payload.get("url")),
                dumps_json(payload.get("headers_json") or {}),
                timeout_seconds,
                1 if bool(payload.get("is_enabled", True)) else 0,
                1 if bool(payload.get("admin_only", True)) else 0,
            ),
        )
        after = self._find_mcp_server(server_name)
        self._log_config_change(
            config_domain="mcp_server",
            scope_ref=server_name,
            change_type="create",
            before_json=None,
            after_json=after,
            changed_by=changed_by,
        )
        return after or {}

    def update_mcp_server(self, server_name: str, payload: dict[str, Any], *, changed_by: str) -> dict[str, Any]:
        before = self._find_mcp_server(server_name)
        if not before:
            raise ValueError("MCP 服务不存在")
        updates: list[str] = []
        params: list[Any] = []
        for field in ["display_name", "command", "url"]:
            if field in payload:
                updates.append(f"{field}=%s")
                params.append(self._nullable_str(payload[field]))
        if "transport" in payload:
            updates.append("transport=%s")
            params.append(self._validate_mcp_transport(payload["transport"]))
        if "timeout_seconds" in payload:
            updates.append("timeout_seconds=%s")
            params.append(min(120, max(1, int(payload["timeout_seconds"] or 15))))
        if "is_enabled" in payload:
            updates.append("is_enabled=%s")
            params.append(1 if bool(payload["is_enabled"]) else 0)
        if "admin_only" in payload:
            updates.append("admin_only=%s")
            params.append(1 if bool(payload["admin_only"]) else 0)
        for field in ["args_json", "env_json", "headers_json"]:
            if field in payload:
                updates.append(f"{field}=%s")
                fallback = [] if field == "args_json" else {}
                params.append(dumps_json(payload[field] if payload[field] is not None else fallback))
        if not updates:
            return before
        params.append(server_name)
        database.execute(
            f"UPDATE bot_mcp_server_config SET {', '.join(updates)} WHERE server_name=%s",
            tuple(params),
        )
        if "is_enabled" in payload and not bool(payload["is_enabled"]):
            database.execute(
                "UPDATE bot_mcp_tool_cache SET is_enabled=0 WHERE server_name=%s",
                (server_name,),
            )
        after = self._find_mcp_server(server_name)
        self._log_config_change(
            config_domain="mcp_server",
            scope_ref=server_name,
            change_type="update",
            before_json=before,
            after_json=after,
            changed_by=changed_by,
        )
        return after or before

    def delete_mcp_server(self, server_name: str, *, changed_by: str) -> dict[str, Any]:
        before = self._find_mcp_server(server_name)
        if not before:
            raise ValueError("MCP 服务不存在")
        database.execute("DELETE FROM bot_mcp_tool_cache WHERE server_name=%s", (server_name,))
        database.execute("DELETE FROM bot_mcp_server_config WHERE server_name=%s", (server_name,))
        result = {"deleted": True, "server_name": server_name}
        self._log_config_change(
            config_domain="mcp_server",
            scope_ref=server_name,
            change_type="delete",
            before_json=before,
            after_json=result,
            changed_by=changed_by,
        )
        return result

    async def test_mcp_server(self, server_name: str) -> dict[str, Any]:
        try:
            return await self.tools.test_mcp_server(server_name)
        except Exception as exc:
            raise ValueError(self._public_error(exc)) from exc

    async def refresh_mcp_tools(self, server_name: str, *, changed_by: str) -> dict[str, Any]:
        before = self.list_mcp_tools(server_name=server_name)
        try:
            result = await self.tools.refresh_mcp_tools(server_name)
        except Exception as exc:
            raise ValueError(self._public_error(exc)) from exc
        after = self.list_mcp_tools(server_name=server_name)
        self._log_config_change(
            config_domain="mcp_tool",
            scope_ref=server_name,
            change_type="refresh",
            before_json=before,
            after_json={"result": result, "tools": after},
            changed_by=changed_by,
        )
        return result

    async def install_mcp_preset(self, preset_name: str, *, changed_by: str) -> dict[str, Any]:
        preset = self.MCP_PRESETS.get(str(preset_name or "").strip())
        if not preset:
            raise ValueError("未知 MCP 预设")

        install_logs = self._run_mcp_preset_install_steps(preset)
        payload = {
            "server_name": preset["server_name"],
            "display_name": preset["display_name"],
            "transport": preset["transport"],
            "command": preset["command"],
            "args_json": preset["args_json"],
            "env_json": preset["env_json"],
            "url": "",
            "headers_json": {},
            "timeout_seconds": preset["timeout_seconds"],
            "is_enabled": True,
            "admin_only": preset["admin_only"],
        }
        before = self._find_mcp_server(str(preset["server_name"]))
        if before:
            server = self.update_mcp_server(str(preset["server_name"]), payload, changed_by=changed_by)
            action = "update"
        else:
            server = self.create_mcp_server(payload, changed_by=changed_by)
            action = "create"

        try:
            refresh_result = await self.refresh_mcp_tools(str(preset["server_name"]), changed_by=changed_by)
        except Exception as exc:
            raise ValueError(self._public_error(exc)) from exc

        return {
            "ok": True,
            "action": action,
            "server": server,
            "install_logs": install_logs,
            "refresh": refresh_result,
        }

    def list_mcp_tools(self, *, server_name: str = "") -> list[dict[str, Any]]:
        filters: list[str] = []
        params: list[Any] = []
        if server_name:
            filters.append("t.server_name=%s")
            params.append(server_name)
        where_sql = f"WHERE {' AND '.join(filters)}" if filters else ""
        rows = database.fetch_all(
            f"""
            SELECT
                t.id, t.server_name, t.exposed_tool_name, t.original_tool_name,
                t.display_name, t.description, t.parameters_json, t.is_enabled,
                t.admin_only, t.last_seen_at, t.created_at, t.updated_at,
                s.is_enabled AS server_enabled, s.admin_only AS server_admin_only
            FROM bot_mcp_tool_cache t
            INNER JOIN bot_mcp_server_config s ON t.server_name=s.server_name
            {where_sql}
            ORDER BY t.server_name ASC, t.original_tool_name ASC
            """,
            tuple(params),
        )
        for row in rows:
            row["parameters_json"] = loads_json(
                str(row.get("parameters_json")) if row.get("parameters_json") is not None else None,
                {},
            )
        return rows

    def list_mcp_tool_call_logs(
        self,
        *,
        page: int,
        page_size: int,
        server_name: str = "",
        exposed_tool_name: str = "",
        session_type: str = "",
        session_id: int | None = None,
        is_success: bool | None = None,
        start_at: str = "",
        end_at: str = "",
    ) -> dict[str, Any]:
        filters: list[str] = []
        params: list[Any] = []
        if server_name:
            filters.append("server_name=%s")
            params.append(server_name)
        if exposed_tool_name:
            filters.append("exposed_tool_name=%s")
            params.append(exposed_tool_name)
        if session_type:
            filters.append("session_type=%s")
            params.append(session_type)
        if session_id is not None:
            filters.append("session_id=%s")
            params.append(session_id)
        if is_success is not None:
            filters.append("is_success=%s")
            params.append(1 if is_success else 0)
        if start_at:
            filters.append("created_at >= %s")
            params.append(start_at)
        if end_at:
            filters.append("created_at <= %s")
            params.append(end_at)

        result = self._paged_query(
            table_sql="FROM bot_mcp_tool_call_log",
            filters=filters,
            params=params,
            order_by="created_at DESC, id DESC",
            page=page,
            page_size=page_size,
            columns=(
                "id, session_type, session_id, user_id, server_name, exposed_tool_name, "
                "original_tool_name, arguments_json, result_excerpt, error_text, "
                "is_success, latency_ms, created_at"
            ),
        )
        for row in result["items"]:
            row["arguments_json"] = loads_json(
                str(row.get("arguments_json")) if row.get("arguments_json") is not None else None,
                {},
            )
        return result

    def update_mcp_tool(self, exposed_tool_name: str, payload: dict[str, Any], *, changed_by: str) -> dict[str, Any]:
        before = self._find_mcp_tool(exposed_tool_name)
        if not before:
            raise ValueError("MCP 工具不存在")
        updates: list[str] = []
        params: list[Any] = []
        for field in ["display_name", "description"]:
            if field in payload:
                updates.append(f"{field}=%s")
                params.append(payload[field])
        if "parameters_json" in payload:
            updates.append("parameters_json=%s")
            params.append(dumps_json(payload["parameters_json"]) if payload["parameters_json"] is not None else None)
        if "is_enabled" in payload:
            updates.append("is_enabled=%s")
            params.append(1 if bool(payload["is_enabled"]) else 0)
        if "admin_only" in payload:
            updates.append("admin_only=%s")
            params.append(1 if bool(payload["admin_only"]) else 0)
        if not updates:
            return before
        params.append(exposed_tool_name)
        database.execute(
            f"UPDATE bot_mcp_tool_cache SET {', '.join(updates)} WHERE exposed_tool_name=%s",
            tuple(params),
        )
        after = self._find_mcp_tool(exposed_tool_name)
        self._log_config_change(
            config_domain="mcp_tool",
            scope_ref=exposed_tool_name,
            change_type="update",
            before_json=before,
            after_json=after,
            changed_by=changed_by,
        )
        return after or before

    def list_admin_users(self) -> list[dict[str, Any]]:
        return self.admin_auth_service.list_admin_users()

    def create_admin_user(
        self,
        *,
        user_id: int,
        nickname: str | None,
        is_active: bool,
        changed_by: str,
    ) -> dict[str, Any]:
        before = self._find_admin_user(user_id)
        row = self.admin_auth_service.create_admin_user(user_id, nickname, is_active=is_active)
        self._log_config_change(
            config_domain="admin_user",
            scope_ref=f"user:{user_id}",
            change_type="update" if before else "create",
            before_json=before,
            after_json=row,
            changed_by=changed_by,
        )
        return row

    def update_admin_user(
        self,
        *,
        user_id: int,
        nickname: str | None,
        is_active: bool | None,
        changed_by: str,
    ) -> dict[str, Any]:
        before = self._find_admin_user(user_id)
        row = self.admin_auth_service.update_admin_user(user_id, nickname=nickname, is_active=is_active)
        self._log_config_change(
            config_domain="admin_user",
            scope_ref=f"user:{user_id}",
            change_type="update",
            before_json=before,
            after_json=row,
            changed_by=changed_by,
        )
        return row

    def list_group_configs(self, *, page: int, page_size: int, keyword: str = "") -> dict[str, Any]:
        filters = []
        params: list[Any] = []
        if keyword.strip():
            filters.append("(CAST(group_id AS CHAR) LIKE %s OR group_name LIKE %s)")
            like = f"%{keyword.strip()}%"
            params.extend([like, like])
        return self._paged_query(
            table_sql="FROM bot_group_config",
            filters=filters,
            params=params,
            order_by="updated_at DESC, group_id DESC",
            page=page,
            page_size=page_size,
            columns="group_id, group_name, reply_rate, is_sleeping, enable_ai, enable_summary, updated_at",
        )

    def update_group_config(self, group_id: int, payload: dict[str, Any], *, changed_by: str) -> dict[str, Any]:
        before = database.fetch_one("SELECT * FROM bot_group_config WHERE group_id=%s", (group_id,))
        row = before or {
            "group_id": group_id,
            "group_name": None,
            "reply_rate": 100,
            "is_sleeping": 0,
            "enable_ai": 1,
            "enable_summary": 1,
        }
        database.execute(
            """
            INSERT INTO bot_group_config(group_id, group_name, reply_rate, is_sleeping, enable_ai, enable_summary, updated_by)
            VALUES(%s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                group_name=VALUES(group_name),
                reply_rate=VALUES(reply_rate),
                is_sleeping=VALUES(is_sleeping),
                enable_ai=VALUES(enable_ai),
                enable_summary=VALUES(enable_summary),
                updated_by=VALUES(updated_by)
            """,
            (
                group_id,
                payload.get("group_name", row.get("group_name")),
                payload.get("reply_rate", row.get("reply_rate")),
                1 if bool(payload.get("is_sleeping", row.get("is_sleeping"))) else 0,
                1 if bool(payload.get("enable_ai", row.get("enable_ai"))) else 0,
                1 if bool(payload.get("enable_summary", row.get("enable_summary"))) else 0,
                changed_by,
            ),
        )
        after = database.fetch_one("SELECT * FROM bot_group_config WHERE group_id=%s", (group_id,))
        self._log_config_change(
            config_domain="group_config",
            scope_ref=f"group:{group_id}",
            change_type="update" if before else "create",
            before_json=before,
            after_json=after,
            changed_by=changed_by,
        )
        return after or row

    def list_private_configs(self, *, page: int, page_size: int, keyword: str = "") -> dict[str, Any]:
        filters = []
        params: list[Any] = []
        if keyword.strip():
            filters.append("(CAST(user_id AS CHAR) LIKE %s OR user_nickname LIKE %s)")
            like = f"%{keyword.strip()}%"
            params.extend([like, like])
        return self._paged_query(
            table_sql="FROM bot_private_config",
            filters=filters,
            params=params,
            order_by="updated_at DESC, user_id DESC",
            page=page,
            page_size=page_size,
            columns="user_id, user_nickname, reply_rate, is_sleeping, enable_ai, enable_summary, updated_at",
        )

    def update_private_config(self, user_id: int, payload: dict[str, Any], *, changed_by: str) -> dict[str, Any]:
        before = database.fetch_one("SELECT * FROM bot_private_config WHERE user_id=%s", (user_id,))
        row = before or {
            "user_id": user_id,
            "user_nickname": None,
            "reply_rate": 100,
            "is_sleeping": 0,
            "enable_ai": 1,
            "enable_summary": 1,
        }
        database.execute(
            """
            INSERT INTO bot_private_config(user_id, user_nickname, reply_rate, is_sleeping, enable_ai, enable_summary, updated_by)
            VALUES(%s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                user_nickname=VALUES(user_nickname),
                reply_rate=VALUES(reply_rate),
                is_sleeping=VALUES(is_sleeping),
                enable_ai=VALUES(enable_ai),
                enable_summary=VALUES(enable_summary),
                updated_by=VALUES(updated_by)
            """,
            (
                user_id,
                payload.get("user_nickname", row.get("user_nickname")),
                payload.get("reply_rate", row.get("reply_rate")),
                1 if bool(payload.get("is_sleeping", row.get("is_sleeping"))) else 0,
                1 if bool(payload.get("enable_ai", row.get("enable_ai"))) else 0,
                1 if bool(payload.get("enable_summary", row.get("enable_summary"))) else 0,
                changed_by,
            ),
        )
        after = database.fetch_one("SELECT * FROM bot_private_config WHERE user_id=%s", (user_id,))
        self._log_config_change(
            config_domain="private_config",
            scope_ref=f"user:{user_id}",
            change_type="update" if before else "create",
            before_json=before,
            after_json=after,
            changed_by=changed_by,
        )
        return after or row

    def list_messages(
        self,
        *,
        session_type: str,
        page: int,
        page_size: int,
        session_id: int | None = None,
        sender_user_id: int | None = None,
        role: str = "",
        keyword: str = "",
        start_at: str = "",
        end_at: str = "",
        is_reply: bool | None = None,
        is_tool: bool | None = None,
    ) -> dict[str, Any]:
        if session_id is None:
            return {"items": [], "page": max(1, page), "page_size": max(1, min(page_size, 200)), "total": 0}
        return session_store.list_messages_for_admin(
            session_type=session_type,
            session_id=session_id,
            page=page,
            page_size=page_size,
            sender_user_id=sender_user_id,
            role=role,
            keyword=keyword,
            start_at=start_at,
            end_at=end_at,
            is_reply=is_reply,
            is_tool=is_tool,
        )

    def list_message_sessions(
        self,
        *,
        session_type: str,
        keyword: str = "",
    ) -> list[dict[str, Any]]:
        sessions = session_store.list_registered_sessions(session_type, keyword=keyword)
        for item in sessions:
            item["display_name"] = item.get("display_name") or (
                f"群聊 {item['session_id']}" if session_type == "group" else f"QQ {item['session_id']}"
            )
        return sessions

    def delete_message_session(
        self,
        *,
        session_type: str,
        session_id: int,
        changed_by: str,
    ) -> dict[str, Any]:
        before = {
            "session_type": session_type,
            "session_id": session_id,
            "registry": next(
                (item for item in self.list_message_sessions(session_type=session_type) if int(item["session_id"]) == int(session_id)),
                None,
            ),
        }
        result = session_store.delete_session_for_admin(
            session_type=session_type,
            session_id=session_id,
        )
        self._log_config_change(
            config_domain="message_session",
            scope_ref=f"{session_type}:{session_id}",
            change_type="delete",
            before_json=before,
            after_json=result,
            changed_by=changed_by,
        )
        return result

    def get_message_detail(self, *, session_type: str, session_id: int, message_id: int) -> dict[str, Any]:
        row = session_store.get_message_for_admin(
            session_type=session_type,
            session_id=session_id,
            message_id=message_id,
        )
        if not row:
            raise ValueError("消息不存在")
        return row

    def update_message(
        self,
        *,
        session_type: str,
        session_id: int,
        message_id: int,
        payload: dict[str, Any],
        changed_by: str,
    ) -> dict[str, Any]:
        before = self.get_message_detail(
            session_type=session_type,
            session_id=session_id,
            message_id=message_id,
        )
        after = session_store.update_message_for_admin(
            session_type=session_type,
            session_id=session_id,
            message_id=message_id,
            payload=payload,
        )
        if not after:
            raise ValueError("消息不存在")
        self._log_config_change(
            config_domain="message_edit",
            scope_ref=f"{session_type}:{session_id}:message:{message_id}",
            change_type="update",
            before_json=before,
            after_json=after,
            changed_by=changed_by,
        )
        return after

    def delete_messages(
        self,
        *,
        session_type: str,
        session_id: int,
        message_ids: list[int],
        changed_by: str,
    ) -> dict[str, Any]:
        before_rows = []
        for message_id in message_ids:
            row = session_store.get_message_for_admin(
                session_type=session_type,
                session_id=session_id,
                message_id=message_id,
            )
            if row:
                before_rows.append(row)
        deleted = session_store.delete_messages_for_admin(
            session_type=session_type,
            session_id=session_id,
            message_ids=message_ids,
        )
        self._log_config_change(
            config_domain="message_delete",
            scope_ref=f"{session_type}:{session_id}",
            change_type="delete",
            before_json=before_rows,
            after_json={"deleted_count": deleted, "message_ids": message_ids},
            changed_by=changed_by,
        )
        return {
            "deleted_count": deleted,
            "message_ids": message_ids,
        }

    def clear_session_messages(
        self,
        *,
        session_type: str,
        session_id: int,
        changed_by: str,
    ) -> dict[str, Any]:
        deleted = session_store.clear_session_for_admin(
            session_type=session_type,
            session_id=session_id,
        )
        self._log_config_change(
            config_domain="message_delete",
            scope_ref=f"{session_type}:{session_id}",
            change_type="delete",
            before_json={"mode": "clear_session"},
            after_json={"deleted_count": deleted, "session_type": session_type, "session_id": session_id},
            changed_by=changed_by,
        )
        return {
            "deleted_count": deleted,
            "session_type": session_type,
            "session_id": session_id,
        }

    def create_summary(self, *, session_type: str, payload: dict[str, Any], changed_by: str) -> dict[str, Any]:
        meta = self._summary_meta(session_type)
        session_id = int(payload.get("session_id") or 0)
        if session_id <= 0:
            raise ValueError("session_id 不能为空")
        summary_text = str(payload.get("summary_text") or "").strip()
        if not summary_text:
            raise ValueError("summary_text 不能为空")
        version_row = database.fetch_one(
            f"SELECT MAX(summary_version) AS max_version FROM {meta['summary_table']} WHERE {meta['summary_key']}=%s",
            (session_id,),
        )
        next_version = int(version_row["max_version"] or 0) + 1 if version_row else 1
        is_active = bool(payload.get("is_active", True))
        if is_active:
            database.execute(
                f"UPDATE {meta['summary_table']} SET is_active=0 WHERE {meta['summary_key']}=%s",
                (session_id,),
            )
        database.execute(
            f"""
            INSERT INTO {meta['summary_table']}(
                {meta['summary_key']}, {meta['name_column']}, summary_version, summary_text, summary_json,
                source_start_message_id, source_end_message_id, source_message_count,
                created_by_model, is_active
            ) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                session_id,
                payload.get("session_name"),
                next_version,
                summary_text,
                dumps_json(payload["summary_json"]) if payload.get("summary_json") is not None else None,
                payload.get("source_start_message_id"),
                payload.get("source_end_message_id"),
                int(payload.get("source_message_count") or 0),
                payload.get("created_by_model"),
                1 if is_active else 0,
            ),
        )
        row = database.fetch_one(
            f"SELECT id FROM {meta['summary_table']} WHERE {meta['summary_key']}=%s AND summary_version=%s LIMIT 1",
            (session_id, next_version),
        )
        self._ensure_active_summary(session_type, session_id)
        self._sync_summary_state_from_active(session_type, session_id)
        created = self.get_summary_detail(session_type=session_type, summary_id=int(row["id"])) if row else {}
        self._log_config_change(
            config_domain="summary",
            scope_ref=f"{session_type}:{session_id}",
            change_type="create",
            before_json=None,
            after_json=created,
            changed_by=changed_by,
        )
        return created

    def get_summary_detail(self, *, session_type: str, summary_id: int) -> dict[str, Any]:
        meta = self._summary_meta(session_type)
        row = database.fetch_one(
            f"""
            SELECT
                s.id, s.{meta['summary_key']} AS session_id, s.{meta['name_column']} AS session_name,
                s.summary_version, s.summary_text, s.summary_json,
                s.source_start_message_id, s.source_end_message_id, s.source_message_count,
                s.created_by_model, s.is_active, s.created_at, s.updated_at,
                st.last_message_id, st.last_summary_message_id, st.summary_version AS current_summary_version, st.summary_cooldown_until
            FROM {meta['summary_table']} s
            LEFT JOIN {meta['state_table']} st ON s.{meta['summary_key']}=st.{meta['state_key']}
            WHERE s.id=%s
            LIMIT 1
            """,
            (int(summary_id),),
        )
        if not row:
            raise ValueError("摘要不存在")
        row["summary_json"] = loads_json(
            str(row.get("summary_json")) if row.get("summary_json") is not None else None,
            row.get("summary_json"),
        )
        return row

    def update_summary(
        self,
        *,
        session_type: str,
        summary_id: int,
        payload: dict[str, Any],
        changed_by: str,
    ) -> dict[str, Any]:
        before = self.get_summary_detail(session_type=session_type, summary_id=summary_id)
        meta = self._summary_meta(session_type)
        updates: list[str] = []
        params: list[Any] = []
        for field in ["summary_text", "created_by_model", "source_start_message_id", "source_end_message_id", "source_message_count"]:
            if field not in payload:
                continue
            value = payload[field]
            if field == "source_message_count" and value is not None:
                value = int(value)
            updates.append(f"{field}=%s")
            params.append(value)
        if "session_name" in payload:
            updates.append(f"{meta['name_column']}=%s")
            params.append(payload["session_name"])
        if "summary_json" in payload:
            updates.append("summary_json=%s")
            params.append(dumps_json(payload["summary_json"]) if payload["summary_json"] is not None else None)
        if "is_active" in payload:
            is_active = bool(payload["is_active"])
            if is_active:
                database.execute(
                    f"UPDATE {meta['summary_table']} SET is_active=0 WHERE {meta['summary_key']}=%s",
                    (before["session_id"],),
                )
            updates.append("is_active=%s")
            params.append(1 if is_active else 0)
        if not updates:
            return before
        params.append(int(summary_id))
        database.execute(
            f"UPDATE {meta['summary_table']} SET {', '.join(updates)} WHERE id=%s",
            tuple(params),
        )
        self._ensure_active_summary(session_type, int(before["session_id"]))
        self._sync_summary_state_from_active(session_type, int(before["session_id"]))
        after = self.get_summary_detail(session_type=session_type, summary_id=summary_id)
        self._log_config_change(
            config_domain="summary",
            scope_ref=f"{session_type}:{before['session_id']}:summary:{summary_id}",
            change_type="update",
            before_json=before,
            after_json=after,
            changed_by=changed_by,
        )
        return after

    def delete_summary(self, *, session_type: str, summary_id: int, changed_by: str) -> dict[str, Any]:
        before = self.get_summary_detail(session_type=session_type, summary_id=summary_id)
        meta = self._summary_meta(session_type)
        database.execute(f"DELETE FROM {meta['summary_table']} WHERE id=%s", (int(summary_id),))
        self._ensure_active_summary(session_type, int(before["session_id"]))
        self._sync_summary_state_from_active(session_type, int(before["session_id"]))
        result = {"deleted": True, "summary_id": int(summary_id)}
        self._log_config_change(
            config_domain="summary",
            scope_ref=f"{session_type}:{before['session_id']}:summary:{summary_id}",
            change_type="delete",
            before_json=before,
            after_json=result,
            changed_by=changed_by,
        )
        return result

    def list_summaries(
        self,
        *,
        session_type: str,
        page: int,
        page_size: int,
        session_id: int | None = None,
        is_active: bool | None = None,
    ) -> dict[str, Any]:
        summary_table = "bot_group_summary" if session_type == "group" else "bot_private_summary"
        state_table = "bot_group_session_state" if session_type == "group" else "bot_private_session_state"
        summary_key = "group_id" if session_type == "group" else "peer_user_id"
        state_key = "group_id" if session_type == "group" else "user_id"
        name_column = "group_name" if session_type == "group" else "peer_nickname"
        filters: list[str] = []
        params: list[Any] = []
        if session_id is not None:
            filters.append(f"s.{summary_key}=%s")
            params.append(session_id)
        if is_active is not None:
            filters.append("s.is_active=%s")
            params.append(1 if is_active else 0)
        return self._paged_query(
            table_sql=f"FROM {summary_table} s LEFT JOIN {state_table} st ON s.{summary_key}=st.{state_key}",
            filters=filters,
            params=params,
            order_by="s.updated_at DESC, s.id DESC",
            page=page,
            page_size=page_size,
            columns=(
                f"s.id, s.{summary_key} AS session_id, s.{name_column} AS session_name, s.summary_version, s.summary_text, s.summary_json, "
                "s.source_start_message_id, s.source_end_message_id, s.source_message_count, "
                "s.created_by_model, s.is_active, s.created_at, s.updated_at, "
                "st.last_message_id, st.last_summary_message_id, st.summary_version AS current_summary_version, st.summary_cooldown_until"
            ),
        )

    def _summary_meta(self, session_type: str) -> dict[str, str]:
        return {
            "summary_table": "bot_group_summary" if session_type == "group" else "bot_private_summary",
            "state_table": "bot_group_session_state" if session_type == "group" else "bot_private_session_state",
            "summary_key": "group_id" if session_type == "group" else "peer_user_id",
            "state_key": "group_id" if session_type == "group" else "user_id",
            "name_column": "group_name" if session_type == "group" else "peer_nickname",
        }

    def _ensure_active_summary(self, session_type: str, session_id: int) -> None:
        meta = self._summary_meta(session_type)
        active_row = database.fetch_one(
            f"SELECT id FROM {meta['summary_table']} WHERE {meta['summary_key']}=%s AND is_active=1 LIMIT 1",
            (session_id,),
        )
        if active_row:
            return
        latest_row = database.fetch_one(
            f"""
            SELECT id
            FROM {meta['summary_table']}
            WHERE {meta['summary_key']}=%s
            ORDER BY summary_version DESC, id DESC
            LIMIT 1
            """,
            (session_id,),
        )
        if latest_row:
            database.execute(
                f"UPDATE {meta['summary_table']} SET is_active=1 WHERE id=%s",
                (int(latest_row["id"]),),
            )

    def _sync_summary_state_from_active(self, session_type: str, session_id: int) -> None:
        meta = self._summary_meta(session_type)
        active_row = database.fetch_one(
            f"""
            SELECT summary_version, source_end_message_id
            FROM {meta['summary_table']}
            WHERE {meta['summary_key']}=%s AND is_active=1
            ORDER BY summary_version DESC, id DESC
            LIMIT 1
            """,
            (session_id,),
        )
        state = database.fetch_one(
            f"SELECT last_message_id, summary_cooldown_until FROM {meta['state_table']} WHERE {meta['state_key']}=%s",
            (session_id,),
        ) or {}
        if active_row:
            database.execute(
                f"""
                INSERT INTO {meta['state_table']}({meta['state_key']}, last_message_id, last_summary_message_id, summary_version, summary_cooldown_until)
                VALUES(%s, %s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE
                    last_message_id=VALUES(last_message_id),
                    last_summary_message_id=VALUES(last_summary_message_id),
                    summary_version=VALUES(summary_version),
                    summary_cooldown_until=VALUES(summary_cooldown_until)
                """,
                (
                    session_id,
                    state.get("last_message_id"),
                    int(active_row.get("source_end_message_id") or 0),
                    int(active_row.get("summary_version") or 0),
                    state.get("summary_cooldown_until"),
                ),
            )
            return
        database.execute(
            f"""
            INSERT INTO {meta['state_table']}({meta['state_key']}, last_message_id, last_summary_message_id, summary_version, summary_cooldown_until)
            VALUES(%s, %s, 0, 0, %s)
            ON DUPLICATE KEY UPDATE
                last_message_id=VALUES(last_message_id),
                last_summary_message_id=VALUES(last_summary_message_id),
                summary_version=VALUES(summary_version),
                summary_cooldown_until=VALUES(summary_cooldown_until)
            """,
            (
                session_id,
                state.get("last_message_id"),
                state.get("summary_cooldown_until"),
            ),
        )

    def list_ai_call_logs(
        self,
        *,
        page: int,
        page_size: int,
        session_type: str = "",
        session_id: int | None = None,
        stage: str = "",
        model_name: str = "",
        failure_reason: str = "",
        is_success: bool | None = None,
        start_at: str = "",
        end_at: str = "",
    ) -> dict[str, Any]:
        filters: list[str] = []
        params: list[Any] = []
        if session_type:
            filters.append("session_type=%s")
            params.append(session_type)
        if session_id is not None:
            filters.append("session_id=%s")
            params.append(session_id)
        if stage:
            filters.append("stage=%s")
            params.append(stage)
        if model_name:
            filters.append("model_name LIKE %s")
            params.append(f"%{model_name}%")
        if failure_reason:
            filters.append("failure_reason=%s")
            params.append(failure_reason)
        if is_success is not None:
            filters.append("is_success=%s")
            params.append(1 if is_success else 0)
        if start_at:
            filters.append("created_at >= %s")
            params.append(start_at)
        if end_at:
            filters.append("created_at <= %s")
            params.append(end_at)
        return self._paged_query(
            table_sql="FROM bot_ai_call_log",
            filters=filters,
            params=params,
            order_by="created_at DESC, id DESC",
            page=page,
            page_size=page_size,
            columns=(
                "id, session_type, session_id, message_table, message_row_id, stage, model_name, "
                "fallback_index, allow_tools, failure_reason, is_success, latency_ms, request_excerpt, created_at"
            ),
        )

    def _paged_query(
        self,
        *,
        table_sql: str,
        filters: list[str],
        params: list[Any],
        order_by: str,
        page: int,
        page_size: int,
        columns: str,
    ) -> dict[str, Any]:
        safe_page = max(1, page)
        safe_page_size = max(1, min(page_size, 200))
        where_sql = f" WHERE {' AND '.join(filters)}" if filters else ""
        count_row = database.fetch_one(
            f"SELECT COUNT(*) AS total {table_sql}{where_sql}",
            tuple(params),
        )
        total = int(count_row["total"] or 0) if count_row else 0
        rows = database.fetch_all(
            f"SELECT {columns} {table_sql}{where_sql} ORDER BY {order_by} LIMIT %s OFFSET %s",
            tuple([*params, safe_page_size, (safe_page - 1) * safe_page_size]),
        )
        return {
            "items": rows,
            "page": safe_page,
            "page_size": safe_page_size,
            "total": total,
        }

    def _count(self, sql: str, params: tuple[Any, ...]) -> int:
        row = database.fetch_one(sql, params)
        return int(row["total"] or 0) if row else 0

    @staticmethod
    def _public_error(exc: Exception) -> str:
        text = str(exc).strip() or exc.__class__.__name__
        text = re.sub(r"sk-[A-Za-z0-9_-]+", "sk-***", text)
        return text[:500]

    def _log_config_change(
        self,
        *,
        config_domain: str,
        scope_ref: str,
        change_type: str,
        before_json: Any,
        after_json: Any,
        changed_by: str,
    ) -> None:
        database.execute(
            """
            INSERT INTO bot_config_change_log(
                config_domain, scope_ref, change_type, before_json, after_json, changed_by
            ) VALUES(%s, %s, %s, %s, %s, %s)
            """,
            (
                config_domain,
                scope_ref,
                change_type,
                dumps_json(before_json) if before_json is not None else None,
                dumps_json(after_json) if after_json is not None else None,
                changed_by,
            ),
        )

    def _find_secret_public(self, secret_key: str) -> dict[str, Any] | None:
        for item in self.secret_service.list_secrets():
            if item["secret_key"] == secret_key:
                return item
        return None

    def _find_admin_user(self, user_id: int) -> dict[str, Any] | None:
        for item in self.admin_auth_service.list_admin_users():
            if int(item["user_id"]) == int(user_id):
                return item
        return None

    def _find_tool_config(self, tool_name: str) -> dict[str, Any] | None:
        rows = [item for item in self.list_tools() if str(item.get("tool_name")) == str(tool_name)]
        return rows[0] if rows else None

    def _find_mcp_server(self, server_name: str) -> dict[str, Any] | None:
        rows = [item for item in self.list_mcp_servers() if str(item.get("server_name")) == str(server_name)]
        return rows[0] if rows else None

    def _find_mcp_tool(self, exposed_tool_name: str) -> dict[str, Any] | None:
        rows = [
            item
            for item in self.list_mcp_tools()
            if str(item.get("exposed_tool_name")) == str(exposed_tool_name)
        ]
        return rows[0] if rows else None

    def _run_mcp_preset_install_steps(self, preset: dict[str, Any]) -> list[dict[str, Any]]:
        logs: list[dict[str, Any]] = []
        repo_path = str(preset.get("prepare_git_repo") or "").strip()
        if repo_path:
            self._ensure_git_repo(repo_path, logs)
        for command in preset.get("install_steps") or []:
            logs.append(self._run_mcp_preset_command([str(item) for item in command]))
        return logs

    def _ensure_git_repo(self, repo_path: str, logs: list[dict[str, Any]]) -> None:
        path = Path(repo_path)
        if not path.exists():
            return
        check = self._run_mcp_preset_command(
            ["git", "-C", repo_path, "rev-parse", "--is-inside-work-tree"],
            check=False,
        )
        logs.append(check)
        if check["returncode"] == 0:
            return
        logs.append(self._run_mcp_preset_command(["git", "-C", repo_path, "init"]))
        logs.append(self._run_mcp_preset_command(["git", "-C", repo_path, "config", "user.email", "qqcat@local"]))
        logs.append(self._run_mcp_preset_command(["git", "-C", repo_path, "config", "user.name", "QQcat"]))

    def _run_mcp_preset_command(self, command: list[str], *, check: bool = True) -> dict[str, Any]:
        try:
            completed = subprocess.run(
                command,
                capture_output=True,
                check=False,
                text=True,
                timeout=180,
            )
        except FileNotFoundError as exc:
            raise ValueError(f"命令不存在，请先安装: {command[0]}") from exc
        except subprocess.TimeoutExpired as exc:
            raise ValueError(f"MCP 安装命令超时: {' '.join(command)}") from exc

        log = {
            "command": command,
            "returncode": completed.returncode,
            "stdout": (completed.stdout or "")[-1000:],
            "stderr": (completed.stderr or "")[-1000:],
        }
        if check and completed.returncode != 0:
            message = (completed.stderr or completed.stdout or "命令执行失败").strip()
            raise ValueError(f"MCP 安装失败: {message[-500:]}")
        return log

    @staticmethod
    def _validate_mcp_server_name(value: Any) -> str:
        server_name = str(value or "").strip()
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", server_name):
            raise ValueError("server_name 仅允许字母数字下划线，且不能数字开头")
        return server_name

    @staticmethod
    def _validate_mcp_transport(value: Any) -> str:
        transport = str(value or "").strip().lower()
        if transport not in {"stdio", "streamable_http"}:
            raise ValueError("transport 仅支持 stdio 或 streamable_http")
        return transport

    @staticmethod
    def _nullable_str(value: Any) -> str | None:
        text = str(value or "").strip()
        return text or None

    @staticmethod
    def _parse_mcp_json_fields(row: dict[str, Any]) -> None:
        for field, fallback in {
            "args_json": [],
            "env_json": {},
            "headers_json": {},
        }.items():
            value = row.get(field)
            if isinstance(value, (dict, list)):
                continue
            row[field] = loads_json(str(value) if value is not None else None, fallback)
